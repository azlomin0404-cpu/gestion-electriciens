# Gestion Électriciens

تطبيق Flutter أولي لإدارة عمال الكهرباء، بواجهتين عربية وفرنسية.

## المزايا
- إضافة وتعديل وحذف العمال (كهربائي / مساعد كهربائي).
- تحديد طريقة الأجر لكل عامل: أجر يومي أو راتب شهري ثابت بالدينار الجزائري.
- تسجيل يوم كامل أو نصف يوم مع التاريخ.
- تسجيل المبالغ المستلمة (التسبيقات) وملاحظاتها.
- ملخص شهري: أيام العمل، الراتب المستحق (بحسب نظام العامل)، المدفوع، والمتبقي.
- حفظ البيانات محلياً على الهاتف باستخدام SharedPreferences.

## التشغيل
1. ثبّت Flutter SDK و Android Studio.
2. فك ضغط المشروع.
3. افتح مجلد المشروع في Android Studio أو VS Code.
4. نفّذ:
   flutter pub get
   flutter run

لإنشاء APK:
   flutter build apk --release

ملف APK الناتج عادةً:
   build/app/outputs/flutter-apk/app-release.apk

## ملاحظات
- هذه نسخة أولية؛ البيانات محفوظة على نفس الهاتف وليست متزامنة مع أجهزة أخرى.
- يُنصح بأخذ نسخة احتياطية قبل حذف التطبيق أو مسح بياناته.
- تصدير التقرير الشهري إلى PDF وExcel ومشاركته من الهاتف.
- تنبيه: نسخة PDF تستخدم عناوين لاتينية لضمان ظهور النص بشكل صحيح في كل الأجهزة؛ ملف Excel يحتوي على تفاصيل الحسابات.


## V2 updates
- Edit and delete payment/advance entries.
- Show remaining balance separately from overpaid amount.
- Monthly report includes dated payment details.
- Export an individual worker statement PDF with work-day and payment history.
- Existing SharedPreferences keys are retained for local data continuity.
