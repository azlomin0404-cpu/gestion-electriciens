
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';
import 'package:excel/excel.dart';
import 'package:share_plus/share_plus.dart';
import 'dart:typed_data';

void main() => runApp(const GestionApp());

class Worker {
  Worker({required this.id, required this.name, required this.role, required this.dailyRate, this.payType = 'daily', this.monthlySalary = 0});
  final String id;
  String name;
  String role; // electrician | assistant
  double dailyRate;
  String payType; // daily | monthly
  double monthlySalary;

  Map<String, dynamic> toJson() => {
    'id': id, 'name': name, 'role': role, 'dailyRate': dailyRate,
    'payType': payType, 'monthlySalary': monthlySalary,
  };
  factory Worker.fromJson(Map<String, dynamic> j) => Worker(
    id: j['id'], name: j['name'], role: j['role'],
    dailyRate: (j['dailyRate'] as num?)?.toDouble() ?? 0,
    payType: j['payType'] ?? 'daily',
    monthlySalary: (j['monthlySalary'] as num?)?.toDouble() ?? 0,
  );
}

class WorkDay {
  WorkDay({required this.workerId, required this.date, required this.fraction});
  String workerId;
  String date; // yyyy-MM-dd
  double fraction; // 1.0 full day, 0.5 half day
  Map<String, dynamic> toJson() => {'workerId': workerId, 'date': date, 'fraction': fraction};
  factory WorkDay.fromJson(Map<String, dynamic> j) => WorkDay(
    workerId: j['workerId'], date: j['date'], fraction: (j['fraction'] as num).toDouble(),
  );
}

class Advance {
  Advance({required this.workerId, required this.date, required this.amount, this.note = ''});
  String workerId;
  String date;
  double amount;
  String note;
  Map<String, dynamic> toJson() => {
    'workerId': workerId, 'date': date, 'amount': amount, 'note': note,
  };
  factory Advance.fromJson(Map<String, dynamic> j) => Advance(
    workerId: j['workerId'], date: j['date'], amount: (j['amount'] as num).toDouble(),
    note: j['note'] ?? '',
  );
}

class Store extends ChangeNotifier {
  List<Worker> workers = [];
  List<WorkDay> days = [];
  List<Advance> advances = [];
  bool french = false;

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    workers = (jsonDecode(p.getString('workers') ?? '[]') as List).map((e) => Worker.fromJson(e)).toList();
    days = (jsonDecode(p.getString('days') ?? '[]') as List).map((e) => WorkDay.fromJson(e)).toList();
    advances = (jsonDecode(p.getString('advances') ?? '[]') as List).map((e) => Advance.fromJson(e)).toList();
    french = p.getBool('french') ?? false;
    notifyListeners();
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('workers', jsonEncode(workers.map((e) => e.toJson()).toList()));
    await p.setString('days', jsonEncode(days.map((e) => e.toJson()).toList()));
    await p.setString('advances', jsonEncode(advances.map((e) => e.toJson()).toList()));
    await p.setBool('french', french);
    notifyListeners();
  }

  String t(String ar, String fr) => french ? fr : ar;
  String monthKey(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}';
  double worked(Worker w, DateTime month) => days.where((d) =>
    d.workerId == w.id && d.date.startsWith(monthKey(month))).fold(0, (s, d) => s + d.fraction);
  double paid(Worker w, DateTime month) => advances.where((a) =>
    a.workerId == w.id && a.date.startsWith(monthKey(month))).fold(0, (s, a) => s + a.amount);
  double due(Worker w, DateTime month) =>
      w.payType == 'monthly' ? w.monthlySalary : worked(w, month) * w.dailyRate;
}

class GestionApp extends StatefulWidget {
  const GestionApp({super.key});
  @override State<GestionApp> createState() => _GestionAppState();
}
class _GestionAppState extends State<GestionApp> {
  final Store store = Store();
  @override void initState() { super.initState(); store.load(); }
  @override Widget build(BuildContext context) => AnimatedBuilder(
    animation: store,
    builder: (_, __) => MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Gestion Électriciens',
      theme: ThemeData(colorSchemeSeed: const Color(0xff1769aa), useMaterial3: true),
      home: HomePage(store: store),
    ),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.store});
  final Store store;
  @override State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  int tab = 0;
  DateTime month = DateTime.now();
  Store get s => widget.store;

  @override Widget build(BuildContext context) {
    final pages = [
      dashboard(), workersPage(), daysPage(), advancesPage(), reportPage()
    ];
    return Scaffold(
      appBar: AppBar(
        title: Text(s.t('تسيير عمال الكهرباء', 'Gestion des électriciens')),
        actions: [
          TextButton(
            onPressed: () async { s.french = !s.french; await s.save(); },
            child: Text(s.french ? 'العربية' : 'Français'),
          )
        ],
      ),
      body: SafeArea(child: pages[tab]),
      floatingActionButton: tab == 1 ? FloatingActionButton(
        onPressed: addWorker, child: const Icon(Icons.person_add),
      ) : tab == 2 ? FloatingActionButton(
        onPressed: addDay, child: const Icon(Icons.add),
      ) : tab == 3 ? FloatingActionButton(
        onPressed: addAdvance, child: const Icon(Icons.payments),
      ) : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.dashboard), label: s.t('الرئيسية','Accueil')),
          NavigationDestination(icon: const Icon(Icons.people), label: s.t('العمال','Ouvriers')),
          NavigationDestination(icon: const Icon(Icons.calendar_month), label: s.t('اليوميات','Journées')),
          NavigationDestination(icon: const Icon(Icons.account_balance_wallet), label: s.t('التسبيقات','Avances')),
          NavigationDestination(icon: const Icon(Icons.summarize), label: s.t('التقرير','Rapport')),
        ],
      ),
    );
  }

  Widget monthPicker() => Row(mainAxisAlignment: MainAxisAlignment.center, children: [
    IconButton(onPressed: () => setState(() => month = DateTime(month.year, month.month - 1)), icon: const Icon(Icons.chevron_left)),
    Text('${month.year}-${month.month.toString().padLeft(2, '0')}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
    IconButton(onPressed: () => setState(() => month = DateTime(month.year, month.month + 1)), icon: const Icon(Icons.chevron_right)),
  ]);

  Widget dashboard() {
    final totalDue = s.workers.fold<double>(0, (v, w) => v + s.due(w, month));
    final totalPaid = s.workers.fold<double>(0, (v, w) => v + s.paid(w, month));
    return ListView(padding: const EdgeInsets.all(16), children: [
      monthPicker(),
      const SizedBox(height: 8),
      Wrap(spacing: 10, runSpacing: 10, children: [
        metric(s.t('عدد العمال','Ouvriers'), '${s.workers.length}', Icons.people),
        metric(s.t('الراتب المستحق','Salaire dû'), money(totalDue), Icons.payments),
        metric(s.t('المبالغ المدفوعة','Déjà versé'), money(totalPaid), Icons.account_balance_wallet),
        metric(s.t('المتبقي','Reste à payer'), money((totalDue-totalPaid).clamp(0, double.infinity)), Icons.pending_actions),
      ]),
      const SizedBox(height: 18),
      Text(s.t('ملخص العمال','Résumé des ouvriers'), style: Theme.of(context).textTheme.titleLarge),
      ...s.workers.map((w) => workerSummary(w)),
      if (s.workers.isEmpty) empty(s.t('أضف أول عامل للبدء','Ajoutez votre premier ouvrier pour commencer')),
    ]);
  }

  Widget metric(String title, String value, IconData icon) => SizedBox(
    width: (MediaQuery.of(context).size.width - 42) / 2,
    child: Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: Theme.of(context).colorScheme.primary),
        const SizedBox(height: 8), Text(title),
        const SizedBox(height: 4), Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      ],
    ))),
  );

  Widget workerSummary(Worker w) => Card(child: ListTile(
    title: Text(w.name), subtitle: Text('${roleName(w.role)} • ${s.worked(w, month)} ${s.t('يوم','j') }'),
    trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
      Text(money(s.due(w, month)), style: const TextStyle(fontWeight: FontWeight.bold)),
      Text('${s.t('الباقي','Reste')}: ${money((s.due(w, month)-s.paid(w, month)).clamp(0, double.infinity))} • ${s.t('زيادة مدفوعة','Trop-perçu')}: ${money((s.paid(w, month)-s.due(w, month)).clamp(0, double.infinity))}', style: const TextStyle(fontSize: 11)),
    ]),
  ));

  String roleName(String role) => role == 'electrician'
    ? s.t('كهربائي','Électricien') : s.t('مساعد كهربائي','Aide-électricien');
  String money(double v) => '${v.toStringAsFixed(0)} DA';

  Widget workersPage() => ListView(padding: const EdgeInsets.all(12), children: [
    Text(s.t('قائمة العمال','Liste des ouvriers'), style: Theme.of(context).textTheme.titleLarge),
    ...s.workers.map((w) => Card(child: ListTile(
      leading: CircleAvatar(child: Icon(w.role == 'electrician' ? Icons.electrical_services : Icons.handyman)),
      title: Text(w.name), subtitle: Text(
        '${roleName(w.role)} • ${w.payType == 'monthly' ? '${money(w.monthlySalary)} / ${s.t('الشهر','mois')}' : '${money(w.dailyRate)} / ${s.t('اليوم','jour')}'}'),
      trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => confirmDelete(w)),
      onTap: () => editWorker(w),
    ))),
    if (s.workers.isEmpty) empty(s.t('لا يوجد عمال بعد','Aucun ouvrier pour le moment')),
  ]);

  Widget daysPage() => ListView(padding: const EdgeInsets.all(12), children: [
    monthPicker(),
    Text(s.t('سجل أيام العمل','Historique des journées'), style: Theme.of(context).textTheme.titleLarge),
    ...s.days.where((d) => d.date.startsWith(s.monthKey(month))).toList().reversed.map((d) {
      final w = s.workers.where((w) => w.id == d.workerId).firstOrNull;
      return Card(child: ListTile(
        title: Text(w?.name ?? s.t('عامل محذوف','Ouvrier supprimé')),
        subtitle: Text('${d.date} • ${d.fraction == 1 ? s.t('يوم كامل','Journée complète') : s.t('نصف يوم','Demi-journée')}'),
        trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async { s.days.remove(d); await s.save(); }),
      ));
    }),
    if (s.days.where((d) => d.date.startsWith(s.monthKey(month))).isEmpty) empty(s.t('لا توجد أيام مسجلة لهذا الشهر','Aucune journée enregistrée ce mois-ci')),
  ]);

  Widget advancesPage() => ListView(padding: const EdgeInsets.all(12), children: [
    monthPicker(),
    Text(s.t('الأموال التي استلمها العمال','Avances versées'), style: Theme.of(context).textTheme.titleLarge),
    ...s.advances.where((a) => a.date.startsWith(s.monthKey(month))).toList().reversed.map((a) {
      final w = s.workers.where((w) => w.id == a.workerId).firstOrNull;
      return Card(child: ListTile(
        title: Text(w?.name ?? s.t('عامل محذوف','Ouvrier supprimé')),
        subtitle: Text('${a.date}${a.note.isEmpty ? '' : ' • ${a.note}'}'),
        trailing: PopupMenuButton<String>(
          onSelected: (v) async {
            if (v == 'edit') await editAdvance(a);
            if (v == 'delete') {
              s.advances.remove(a);
              await s.save();
            }
          },
          itemBuilder: (_) => [
            PopupMenuItem(value: 'edit', child: Text(s.t('تعديل','Modifier'))),
            PopupMenuItem(value: 'delete', child: Text(s.t('حذف','Supprimer'))),
          ],
          child: Text(money(a.amount), style: const TextStyle(fontWeight: FontWeight.bold)),
        ),
        onTap: () => editAdvance(a),
      ));
    }),
    if (s.advances.where((a) => a.date.startsWith(s.monthKey(month))).isEmpty) empty(s.t('لا توجد تسبيقات مسجلة','Aucune avance enregistrée')),
  ]);



  Future<void> exportWorkerPdf(Worker w) async {
    final doc = pw.Document();
    final due = s.due(w, month);
    final paid = s.paid(w, month);
    final workerDays = s.days.where((d) =>
      d.workerId == w.id && d.date.startsWith(s.monthKey(month))).toList()
      ..sort((a, b) => a.date.compareTo(b.date));
    final workerAdvances = s.advances.where((a) =>
      a.workerId == w.id && a.date.startsWith(s.monthKey(month))).toList()
      ..sort((a, b) => a.date.compareTo(b.date));
    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      build: (_) => [
        pw.Text('Gestion Electriciens - Worker Statement',
          style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 8),
        pw.Text('Worker: ${w.name}'),
        pw.Text('Role: ${w.role == 'electrician' ? 'Electrician' : 'Assistant electrician'}'),
        pw.Text('Payment: ${w.payType == 'monthly' ? 'Fixed monthly salary' : 'Daily rate'}'),
        pw.Text('Period: ${month.year}-${month.month.toString().padLeft(2,'0')}'),
        pw.SizedBox(height: 12),
        pw.Text('Work days: ${s.worked(w, month)}'),
        pw.Text('Salary due: ${due.toStringAsFixed(0)} DA'),
        pw.Text('Total received: ${paid.toStringAsFixed(0)} DA'),
        pw.Text('Remaining: ${(due-paid).clamp(0, double.infinity).toStringAsFixed(0)} DA'),
        pw.Text('Overpaid: ${(paid-due).clamp(0, double.infinity).toStringAsFixed(0)} DA'),
        pw.SizedBox(height: 16),
        pw.Text('Work days detail', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
        pw.Table.fromTextArray(
          headers: ['Date', 'Work type'],
          data: workerDays.map((d) => [d.date, d.fraction == 1 ? 'Full day' : 'Half day']).toList(),
          headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
        ),
        pw.SizedBox(height: 16),
        pw.Text('Advances / payments detail', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
        pw.Table.fromTextArray(
          headers: ['Date', 'Amount (DA)', 'Note'],
          data: workerAdvances.map((a) => [a.date, a.amount.toStringAsFixed(0), a.note]).toList(),
          headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
        ),
      ],
    ));
    await Printing.sharePdf(bytes: await doc.save(),
      filename: 'statement_${w.name.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '_')}_${month.year}_${month.month}.pdf');
  }

  Future<void> exportPdf() async {
    final doc = pw.Document();
    final rows = <List<String>>[
      [s.french ? 'Ouvrier' : 'العامل',
       s.french ? 'Fonction' : 'الوظيفة',
       s.french ? 'Jours' : 'أيام العمل',
       s.french ? 'Salaire dû (DA)' : 'الراتب المستحق (دج)',
       s.french ? 'Reçu (DA)' : 'المبلغ المستلم (دج)',
       s.french ? 'Reste (DA)' : 'المتبقي (دج)']
    ];
    for (final w in s.workers) {
      final due = s.due(w, month), paid = s.paid(w, month);
      rows.add([
        w.name, roleName(w.role), s.worked(w, month).toStringAsFixed(1),
        due.toStringAsFixed(0), paid.toStringAsFixed(0), (due-paid).toStringAsFixed(0)
      ]);
    }
    // Latin text is guaranteed to render with built-in PDF fonts. For Arabic labels,
    // use transliterated/neutral column labels when the app is in Arabic mode.
    final pdfRows = rows.map((r) => r.map((v) {
      if (RegExp(r'[\u0600-\u06FF]').hasMatch(v)) {
        return v == 'العامل' ? 'Worker' :
          v == 'الوظيفة' ? 'Role' :
          v == 'أيام العمل' ? 'Work days' :
          v == 'الراتب المستحق (دج)' ? 'Salary due (DA)' :
          v == 'المبلغ المستلم (دج)' ? 'Received (DA)' :
          v == 'المتبقي (دج)' ? 'Remaining (DA)' :
          v == 'كهربائي' ? 'Electrician' :
          v == 'مساعد كهربائي' ? 'Assistant electrician' : v;
      }
      return v;
    }).toList()).toList();
    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4.landscape,
      build: (context) => [
        pw.Text('Gestion Electriciens - ${month.year}-${month.month.toString().padLeft(2,'0')}',
          style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 16),
        pw.Table.fromTextArray(
          data: pdfRows,
          headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
          headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
          cellPadding: const pw.EdgeInsets.all(6),
          border: pw.TableBorder.all(color: PdfColors.grey500, width: .5),
        ),
        pw.SizedBox(height: 12),
        pw.Text('Generated by Gestion Electriciens', style: const pw.TextStyle(fontSize: 9)),
      ],
    ));
    final bytes = await doc.save();
    await Printing.sharePdf(bytes: bytes, filename: 'rapport_${month.year}_${month.month}.pdf');
  }

  Future<void> exportExcel() async {
    final book = Excel.createExcel();
    final sheet = book['Rapport'];
    final headers = [
      'Ouvrier', 'Fonction', 'Mode de paiement', 'Jours travaillés',
      'Tarif journalier (DA)', 'Salaire mensuel fixe (DA)',
      'Salaire dû (DA)', 'Montant reçu (DA)', 'Reste à payer (DA)'
    ];
    for (var c = 0; c < headers.length; c++) {
      sheet.cell(CellIndex.indexByColumnRow(columnIndex: c, rowIndex: 0)).value = TextCellValue(headers[c]);
    }
    for (var i = 0; i < s.workers.length; i++) {
      final w = s.workers[i];
      final row = i + 1;
      final values = [
        TextCellValue(w.name),
        TextCellValue(w.role == 'electrician' ? 'Electricien' : 'Aide-electricien'),
        TextCellValue(w.payType == 'monthly' ? 'Mensuel fixe' : 'Journalier'),
        DoubleCellValue(s.worked(w, month)),
        DoubleCellValue(w.dailyRate),
        DoubleCellValue(w.monthlySalary),
        DoubleCellValue(s.due(w, month)),
        DoubleCellValue(s.paid(w, month)),
        DoubleCellValue(s.due(w, month) - s.paid(w, month)),
      ];
      for (var c = 0; c < values.length; c++) {
        sheet.cell(CellIndex.indexByColumnRow(columnIndex: c, rowIndex: row)).value = values[c];
      }
    }
    final bytes = book.encode();
    if (bytes == null) return;
    final file = XFile.fromData(
      Uint8List.fromList(bytes),
      name: 'rapport_${month.year}_${month.month}.xlsx',
      mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    );
    await Share.shareXFiles([file], text: 'Rapport des ouvriers - ${month.year}-${month.month}');
  }

  Widget reportPage() => ListView(padding: const EdgeInsets.all(16), children: [
    monthPicker(),
    Text(s.t('التقرير الشهري','Rapport mensuel'), style: Theme.of(context).textTheme.titleLarge),
    const SizedBox(height: 8),
    Wrap(spacing: 8, runSpacing: 8, children: [
      FilledButton.icon(onPressed: s.workers.isEmpty ? null : exportPdf,
        icon: const Icon(Icons.picture_as_pdf), label: Text(s.t('تصدير PDF','Exporter PDF'))),
      OutlinedButton.icon(onPressed: s.workers.isEmpty ? null : exportExcel,
        icon: const Icon(Icons.table_chart), label: Text(s.t('تصدير Excel','Exporter Excel'))),
    ]),
    const SizedBox(height: 8),
    ...s.workers.map((w) {
      final worked = s.worked(w, month), due = s.due(w, month), paid = s.paid(w, month);
      return Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(w.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
          Text(roleName(w.role)),
          Align(alignment: Alignment.centerRight,
            child: TextButton.icon(
              onPressed: () => exportWorkerPdf(w),
              icon: const Icon(Icons.picture_as_pdf),
              label: Text(s.t('كشف حساب العامل PDF','Relevé PDF')),
            )),
          const Divider(),
          line(s.t('أيام العمل','Jours travaillés'), '$worked'),
          line(w.payType == 'monthly' ? s.t('الراتب الشهري الثابت','Salaire mensuel fixe') : s.t('الأجر اليومي','Tarif journalier'),
            money(w.payType == 'monthly' ? w.monthlySalary : w.dailyRate)),
          line(s.t('الراتب المستحق','Salaire gagné'), money(due)),
          line(s.t('المبلغ المستلم','Montant reçu'), money(paid)),
          const Divider(),
          Text(s.t('تفاصيل التسبيقات','Détail des versements'),
            style: const TextStyle(fontWeight: FontWeight.bold)),
          ...s.advances.where((a) => a.workerId == w.id && a.date.startsWith(s.monthKey(month))).map((a) =>
            Padding(padding: const EdgeInsets.symmetric(vertical: 2),
              child: Text('${a.date} • ${money(a.amount)}${a.note.isEmpty ? '' : ' • ${a.note}'}',
                style: const TextStyle(fontSize: 12)))),
          const Divider(),
          line(s.t('المتبقي للعامل','Reste dû'), money((due-paid).clamp(0, double.infinity)), bold: true),
          line(s.t('زيادة مدفوعة','Trop-perçu'), money((paid-due).clamp(0, double.infinity))),
        ],
      )));
    }),
    if (s.workers.isEmpty) empty(s.t('أضف عمالاً لعرض التقرير','Ajoutez des ouvriers pour voir le rapport')),
    const SizedBox(height: 8),
    Text(s.t('ملاحظة: الحساب = أيام العمل × الأجر اليومي. المتبقي = الراتب المستحق − المبالغ المستلمة.','Calcul : jours travaillés × tarif journalier. Reste : salaire gagné − avances.'),
      style: const TextStyle(fontSize: 12, color: Colors.grey)),
  ]);

  Widget line(String a, String b, {bool bold = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(a), Text(b, style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
    ]),
  );
  Widget empty(String msg) => Padding(padding: const EdgeInsets.all(24), child: Center(child: Text(msg, textAlign: TextAlign.center)));

  Future<void> addWorker() async => workerDialog();
  Future<void> editWorker(Worker w) async => workerDialog(worker: w);
  Future<void> workerDialog({Worker? worker}) async {
    final name = TextEditingController(text: worker?.name ?? '');
    final rate = TextEditingController(text: worker?.dailyRate.toStringAsFixed(0) ?? '');
    final monthly = TextEditingController(text: worker?.monthlySalary.toStringAsFixed(0) ?? '');
    String role = worker?.role ?? 'electrician';
    String payType = worker?.payType ?? 'daily';
    await showDialog(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setD) => AlertDialog(
      title: Text(s.t(worker == null ? 'إضافة عامل' : 'تعديل عامل', worker == null ? 'Ajouter un ouvrier' : 'Modifier ouvrier')),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: InputDecoration(labelText: s.t('اسم العامل','Nom de l’ouvrier'))),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(value: role, decoration: InputDecoration(labelText: s.t('الوظيفة','Fonction')),
          items: [DropdownMenuItem(value: 'electrician', child: Text(s.t('كهربائي','Électricien'))),
            DropdownMenuItem(value: 'assistant', child: Text(s.t('مساعد كهربائي','Aide-électricien')))],
          onChanged: (v) => setD(() => role = v ?? role)),
        DropdownButtonFormField<String>(
          value: payType,
          decoration: InputDecoration(labelText: s.t('طريقة حساب الراتب','Mode de rémunération')),
          items: [
            DropdownMenuItem(value: 'daily', child: Text(s.t('حسب الأيام والعمل اليومي','À la journée'))),
            DropdownMenuItem(value: 'monthly', child: Text(s.t('راتب شهري ثابت','Salaire mensuel fixe'))),
          ],
          onChanged: (v) => setD(() => payType = v ?? payType),
        ),
        if (payType == 'daily')
          TextField(controller: rate, keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: s.t('الأجر اليومي (دج)','Tarif journalier (DA)')))
        else
          TextField(controller: monthly, keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: s.t('الراتب الشهري الثابت (دج)','Salaire mensuel fixe (DA)'))),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: Text(s.t('إلغاء','Annuler'))),
        FilledButton(onPressed: () async {
          final r = double.tryParse(rate.text.replaceAll(',', '.')) ?? 0;
          final m = double.tryParse(monthly.text.replaceAll(',', '.')) ?? 0;
          final selectedAmount = payType == 'daily' ? r : m;
          if (name.text.trim().isEmpty || selectedAmount < 0) return;
          if (worker == null) {
            s.workers.add(Worker(
              id: DateTime.now().microsecondsSinceEpoch.toString(),
              name: name.text.trim(), role: role, dailyRate: r,
              payType: payType, monthlySalary: m,
            ));
          } else {
            worker.name = name.text.trim(); worker.role = role;
            worker.dailyRate = r; worker.payType = payType; worker.monthlySalary = m;
          }
          await s.save(); if (ctx.mounted) Navigator.pop(ctx);
        }, child: Text(s.t('حفظ','Enregistrer'))),
      ],
    )));
  }

  Future<void> addDay() async {
    if (s.workers.isEmpty) { showMsg(s.t('أضف عاملاً أولاً','Ajoutez d’abord un ouvrier')); return; }
    String wid = s.workers.first.id; double fraction = 1; DateTime date = DateTime.now();
    await showDialog(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setD) => AlertDialog(
      title: Text(s.t('تسجيل يوم عمل','Enregistrer une journée')),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        DropdownButtonFormField<String>(value: wid, items: s.workers.map((w) => DropdownMenuItem(value: w.id, child: Text(w.name))).toList(), onChanged: (v) => setD(() => wid = v ?? wid)),
        DropdownButtonFormField<double>(value: fraction, decoration: InputDecoration(labelText: s.t('مدة العمل','Durée')),
          items: [DropdownMenuItem(value: 1, child: Text(s.t('يوم كامل','Journée complète'))), DropdownMenuItem(value: .5, child: Text(s.t('نصف يوم','Demi-journée')))],
          onChanged: (v) => setD(() => fraction = v ?? 1)),
        TextButton.icon(onPressed: () async { final d = await showDatePicker(context: ctx, initialDate: date, firstDate: DateTime(2020), lastDate: DateTime(2100)); if (d != null) setD(() => date = d); },
          icon: const Icon(Icons.date_range), label: Text('${date.year}-${date.month}-${date.day}')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: Text(s.t('إلغاء','Annuler'))),
        FilledButton(onPressed: () async {
          final key = '${date.year}-${date.month.toString().padLeft(2,'0')}-${date.day.toString().padLeft(2,'0')}';
          final exists = s.days.any((d) => d.workerId == wid && d.date == key);
          if (exists) { showMsg(s.t('هذا اليوم مسجل مسبقاً لهذا العامل','Cette journée est déjà enregistrée pour cet ouvrier')); return; }
          s.days.add(WorkDay(workerId: wid, date: key, fraction: fraction)); await s.save();
          if (ctx.mounted) Navigator.pop(ctx);
        }, child: Text(s.t('حفظ','Enregistrer'))),
      ],
    )));
  }

  Future<void> addAdvance() async {
    if (s.workers.isEmpty) { showMsg(s.t('أضف عاملاً أولاً','Ajoutez d’abord un ouvrier')); return; }
    String wid = s.workers.first.id; final amount = TextEditingController(); final note = TextEditingController();
    DateTime date = DateTime.now();
    await showDialog(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setD) => AlertDialog(
      title: Text(s.t('تسجيل مبلغ مستلم','Enregistrer un versement')),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        DropdownButtonFormField<String>(value: wid, items: s.workers.map((w) => DropdownMenuItem(value: w.id, child: Text(w.name))).toList(), onChanged: (v) => setD(() => wid = v ?? wid)),
        TextField(controller: amount, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: s.t('المبلغ بالدينار','Montant en DA'))),
        TextField(controller: note, decoration: InputDecoration(labelText: s.t('ملاحظة (اختياري)','Note (facultative)'))),
        TextButton.icon(onPressed: () async { final d = await showDatePicker(context: ctx, initialDate: date, firstDate: DateTime(2020), lastDate: DateTime(2100)); if (d != null) setD(() => date = d); },
          icon: const Icon(Icons.date_range), label: Text('${date.year}-${date.month}-${date.day}')),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: Text(s.t('إلغاء','Annuler'))),
        FilledButton(onPressed: () async {
          final a = double.tryParse(amount.text.replaceAll(',', '.'));
          if (a == null || a <= 0) return;
          final key = '${date.year}-${date.month.toString().padLeft(2,'0')}-${date.day.toString().padLeft(2,'0')}';
          s.advances.add(Advance(workerId: wid, date: key, amount: a, note: note.text.trim()));
          await s.save(); if (ctx.mounted) Navigator.pop(ctx);
        }, child: Text(s.t('حفظ','Enregistrer'))),
      ],
    )));
  }


  Future<void> editAdvance(Advance a) async {
    final amount = TextEditingController(text: a.amount.toStringAsFixed(0));
    final note = TextEditingController(text: a.note);
    DateTime date = DateTime.tryParse(a.date) ?? DateTime.now();
    await showDialog(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setD) => AlertDialog(
      title: Text(s.t('تعديل التسبيق','Modifier le versement')),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: amount, keyboardType: TextInputType.number,
          decoration: InputDecoration(labelText: s.t('المبلغ بالدينار','Montant en DA'))),
        TextField(controller: note, decoration: InputDecoration(labelText: s.t('ملاحظة','Note'))),
        TextButton.icon(
          onPressed: () async {
            final d = await showDatePicker(context: ctx, initialDate: date,
              firstDate: DateTime(2020), lastDate: DateTime(2100));
            if (d != null) setD(() => date = d);
          },
          icon: const Icon(Icons.date_range),
          label: Text('${date.year}-${date.month}-${date.day}'),
        ),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: Text(s.t('إلغاء','Annuler'))),
        FilledButton(onPressed: () async {
          final value = double.tryParse(amount.text.replaceAll(',', '.'));
          if (value == null || value <= 0) return;
          a.amount = value;
          a.note = note.text.trim();
          a.date = '${date.year}-${date.month.toString().padLeft(2,'0')}-${date.day.toString().padLeft(2,'0')}';
          await s.save();
          if (ctx.mounted) Navigator.pop(ctx);
        }, child: Text(s.t('حفظ','Enregistrer'))),
      ],
    )));
  }

  Future<void> confirmDelete(Worker w) async {
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: Text(s.t('حذف العامل؟','Supprimer l’ouvrier ?')),
      content: Text(s.t('سيبقى سجل الأيام والتسبيقات محفوظاً لكن لن يظهر اسم العامل.','Les journées et avances resteront enregistrées, mais le nom ne sera plus affiché.')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(s.t('إلغاء','Annuler'))),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(s.t('حذف','Supprimer'))),
      ],
    )) ?? false;
    if (ok) { s.workers.remove(w); await s.save(); }
  }
  void showMsg(String msg) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
}
